package com.email.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailGeneratorApplication.class, args);
	}

}
