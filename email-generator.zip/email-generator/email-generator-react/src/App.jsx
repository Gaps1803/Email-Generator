import { useState } from 'react';
import './App.css';
// Add Tesseract.js import
import Tesseract from 'tesseract.js';

function App() {
  const [emailContent, setEmailContent] = useState('');
  const [tone, setTone] = useState('');
  const [reply, setReply] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [ocrLoading, setOcrLoading] = useState(false);
  const [copySuccess, setCopySuccess] = useState('');

  const toneOptions = [
    '',
    'Formal',
    'Friendly',
    'Concise',
    'Appreciative',
    'Apologetic',
    'Direct',
    'Persuasive',
    'Informative',
    'Casual',
    'Professional',
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setReply('');
    try {
      const response = await fetch('http://localhost:8080/api/email/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailContent, tone }),
      });
      if (!response.ok) throw new Error('Failed to generate reply');
      const data = await response.text();
      setReply(data);
    } catch (err) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  // Copy reply to clipboard
  const handleCopy = () => {
    if (reply) {
      navigator.clipboard.writeText(reply);
      setCopySuccess('Copied!');
      setTimeout(() => setCopySuccess(''), 1500);
    }
  };

  // Handle image upload and OCR
  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setOcrLoading(true);
    setError('');
    try {
      const { data: { text } } = await Tesseract.recognize(file, 'eng');
      setEmailContent(text);
    } catch (err) {
      setError('Failed to extract text from image.');
    } finally {
      setOcrLoading(false);
    }
  };

  // Handle paste event for image OCR
  const handlePaste = async (e) => {
    if (e.clipboardData && e.clipboardData.items) {
      const items = Array.from(e.clipboardData.items);
      const imageItem = items.find(item => item.type.indexOf('image') !== -1);
      if (imageItem) {
        setOcrLoading(true);
        setError('');
        const file = imageItem.getAsFile();
        try {
          const { data: { text } } = await Tesseract.recognize(file, 'eng');
          setEmailContent(text);
        } catch (err) {
          setError('Failed to extract text from pasted image.');
        } finally {
          setOcrLoading(false);
        }
        e.preventDefault();
      }
    }
  };

  return (
    <div className="container">
      <h1>Email Reply Generator</h1>
      <form onSubmit={handleSubmit} className="email-form">
        <label>
          Original Email:
          <textarea
            value={emailContent}
            onChange={e => setEmailContent(e.target.value)}
            required
            rows={6}
            placeholder="Paste the email you want to reply to..."
            onPaste={handlePaste}
          />
        </label>
        {ocrLoading && <div style={{ color: '#2563eb', marginBottom: '1rem' }}>Extracting text from image...</div>}
        <label>
          Tone (optional):
          <select
            value={tone}
            onChange={e => setTone(e.target.value)}
            style={{ padding: '1rem', borderRadius: '8px', fontSize: '1.08rem', border: '1.5px solid #cbd5e1', background: '#f8fafc', color: '#000', minWidth: 200 }}
          >
            {toneOptions.map(option => (
              <option key={option} value={option}>{option ? option : 'Select tone (optional)'}</option>
            ))}
          </select>
        </label>
        <button type="submit" disabled={loading || !emailContent}>
          {loading ? 'Generating...' : 'Generate Reply'}
        </button>
      </form>
      {error && <div className="error">{error}</div>}
      {/* Always show the reply section */}
      <div className="reply-section">
        <h2>Generated Reply:</h2>
        <div className="reply-box" style={{ position: 'relative' }}>
          {reply
            ? reply
            : "The generated reply will appear here after you submit the form."
          }
          {/* Copy button, only show if reply exists */}
          {reply && (
            <button
              onClick={handleCopy}
              style={{
                position: 'absolute',
                top: 12,
                right: 12,
                padding: '0.4rem 1rem',
                fontSize: '0.95rem',
                borderRadius: '6px',
                border: 'none',
                background: '#2563eb',
                color: '#fff',
                cursor: 'pointer',
                fontWeight: 600
              }}
            >
              {copySuccess ? copySuccess : 'Copy'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
